OK_FORMAT = True

test = {   'name': 'q2_4',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(visualization) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 1 <= visualization <= 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> visualization == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
