OK_FORMAT = True

test = {   'name': 'q2_3',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> 500000.0 < west_births < 1000000.0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> west_births == 979657\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
