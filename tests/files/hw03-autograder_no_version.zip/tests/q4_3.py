OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': [0, 1, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(histogram_column_y) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> histogram_column_y == 1 or histogram_column_y == 2 or histogram_column_y == 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> histogram_column_y == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
