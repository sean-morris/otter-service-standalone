OK_FORMAT = True

test = {   'name': 'q3_5',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> 1 <= boston_median_bin <= 4\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> boston_median_bin == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
