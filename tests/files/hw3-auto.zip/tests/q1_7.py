OK_FORMAT = True

test = {   'name': 'q1_7',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> highPTER == True or highPTER == False\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> highPTER\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
