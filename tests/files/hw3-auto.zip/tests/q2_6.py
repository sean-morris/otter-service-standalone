OK_FORMAT = True

test = {   'name': 'q2_6',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> type(assoc) is bool\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> assoc\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
