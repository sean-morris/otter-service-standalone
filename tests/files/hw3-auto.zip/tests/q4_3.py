OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': [0, 1, 4],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you assign histogram_column_y to either 1 or 2!\n>>> type(histogram_column_y) == int\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Make sure histogram_column_y is assigned to 1, 2 or 3.\n>>> histogram_column_y == 1 or histogram_column_y == 2 or histogram_column_y == 3\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> histogram_column_y == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
