OK_FORMAT = True

test = {   'name': 'q1_3',
    'points': [2, 2],
    'suites': [   {   'cases': [   {'code': ">>> with_commas == 'Naruto, Sasuke, and Sakura'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> without_commas == 'Naruto Sasuke and Sakura'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
