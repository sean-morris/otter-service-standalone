OK_FORMAT = True

test = {   'name': 'q5_5',
    'points': [0, 5],
    'suites': [   {   'cases': [{'code': '>>> strawberry_sold > 10\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> strawberry_sold\n228', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
