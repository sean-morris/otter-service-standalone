OK_FORMAT = True

test = {   'name': 'q4_2',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> biggest_increase == 47\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 30 <= biggest_increase < 49\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> biggest_increase\n47', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
