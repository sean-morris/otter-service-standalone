OK_FORMAT = True

test = {   'name': 'q3_1',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> (first_division > 0, second_division < 0, third_division > 0, fourth_division > 0)\n(True, True, True, True)', 'hidden': False, 'locked': False},
                                   {   'code': '>>> np.allclose([first_division, second_division, third_division, fourth_division], np.array([5, -51, 50505050, 25]))\nTrue',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
