OK_FORMAT = True

test = {   'name': 'q5_6',
    'points': [0, 5],
    'suites': [   {   'cases': [   {'code': '>>> 45 <= strawberry_total_revenue <= 75\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(strawberry_total_revenue, 49)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
