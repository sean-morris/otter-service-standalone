OK_FORMAT = True

test = {   'name': 'q5_2',
    'points': [4],
    'suites': [{'cases': [{'code': '>>> fruit_inventory.sort(0).column(0).item(0)\n25274', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
