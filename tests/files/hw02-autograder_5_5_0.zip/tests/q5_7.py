OK_FORMAT = True

test = {   'name': 'q5_7',
    'points': [0, 2, 3],
    'suites': [   {   'cases': [   {'code': '>>> remaining_straw_inventory.num_columns\n3', 'hidden': False, 'locked': False},
                                   {'code': ">>> remaining_straw_inventory.column('count').item(0) != 45\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': ">>> remaining_straw_inventory.where(1, 'strawberry')\n"
                                               'box ID | fruit name | count\n'
                                               '57181  | strawberry | 22\n'
                                               '26187  | strawberry | 230\n'
                                               '52357  | strawberry | 0',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
