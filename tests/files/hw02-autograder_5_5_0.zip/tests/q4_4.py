OK_FORMAT = True

test = {   'name': 'q4_4',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> 15 <= average_error <= 25\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(average_error, 20.52029520295203)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
