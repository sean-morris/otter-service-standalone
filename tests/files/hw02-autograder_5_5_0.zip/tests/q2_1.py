OK_FORMAT = True

test = {   'name': 'q2_1',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> fourth_element != -6\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> fourth_element == -10\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
