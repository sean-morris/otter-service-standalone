OK_FORMAT = True

test = {   'name': 'q5_3',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> straw_three_times in {True, False}\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> straw_three_times == False\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
