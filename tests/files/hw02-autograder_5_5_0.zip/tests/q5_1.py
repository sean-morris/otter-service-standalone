OK_FORMAT = True

test = {   'name': 'q5_1',
    'points': [4],
    'suites': [   {   'cases': [{'code': '>>> grocery_fruits.sort(0)\nfruit     | quantity\nbanana    | 12\npeach     | 6\npineapple | 9', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
