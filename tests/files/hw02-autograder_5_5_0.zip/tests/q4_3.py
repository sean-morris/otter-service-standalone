OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> len(first_six_waiting_times)\n6', 'hidden': False, 'locked': False},
                                   {'code': '>>> average_waiting_time_until_seventh\n68.166666666666671', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
