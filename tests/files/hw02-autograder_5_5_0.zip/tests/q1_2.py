OK_FORMAT = True

test = {   'name': 'q1_2',
    'points': [0, 0, 0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> type(anime_characters) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> not any([',' in text for text in anime_characters])\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> 'and ' in anime_characters.item(2)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> len(anime_characters)\n3', 'hidden': False, 'locked': False},
                                   {   'code': ">>> anime_characters.item(0) == 'Naruto' and anime_characters.item(1) == 'Sasuke' and (anime_characters.item(2) == 'and Sakura')\nTrue",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
