OK_FORMAT = True

test = {   'name': 'q3_3',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> len(correct_division) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(correct_division, np.array([10, -101, 101010101, 50]))\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
