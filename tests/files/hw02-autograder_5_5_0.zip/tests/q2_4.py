OK_FORMAT = True

test = {   'name': 'q2_4',
    'points': [4],
    'suites': [{'cases': [{'code': '>>> second_most_recent_population_year == 2014\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
