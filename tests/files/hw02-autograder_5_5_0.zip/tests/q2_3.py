OK_FORMAT = True

test = {   'name': 'q2_3',
    'points': [4],
    'suites': [{'cases': [{'code': '>>> index_of_last_element == 199\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
