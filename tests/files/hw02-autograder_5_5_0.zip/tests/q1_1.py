OK_FORMAT = True

test = {   'name': 'q1_1',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> type(strange_numbers) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(strange_numbers) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(strange_numbers, np.array([3.14159265, 25, 3, 19]), rtol=0.001, atol=0.001)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
