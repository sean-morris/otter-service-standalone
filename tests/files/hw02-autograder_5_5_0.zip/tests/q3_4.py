OK_FORMAT = True

test = {   'name': 'q3_4',
    'points': [1, 1, 1, 1],
    'suites': [   {   'cases': [   {'code': '>>> sum(kelvin_min_temperatures) != 356705.0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum(kelvin_min_temperatures)\n18264353.0', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(kelvin_min_temperatures)\n65000', 'hidden': False, 'locked': False},
                                   {'code': '>>> kelvin_min_temperatures.item(2003)\n290.0', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
