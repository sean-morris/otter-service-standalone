OK_FORMAT = True

test = {   'name': 'q3_2',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> len(divisions) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(divisions, np.array([5, -51, 50505050, 25]))\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
