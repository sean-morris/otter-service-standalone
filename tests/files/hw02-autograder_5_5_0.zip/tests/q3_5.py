OK_FORMAT = True

test = {   'name': 'q3_5',
    'points': [0, 4, 0],
    'suites': [   {   'cases': [   {'code': '>>> type(kelvin_temperature_ranges) is np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(round(sum(kelvin_temperature_ranges)), 768486.67)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(kelvin_temperature_ranges)\n65000', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
