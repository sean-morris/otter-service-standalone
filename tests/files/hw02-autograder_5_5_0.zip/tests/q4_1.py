OK_FORMAT = True

test = {   'name': 'q4_1',
    'points': [0, 0, 2, 2],
    'suites': [   {   'cases': [   {'code': '>>> 40 <= shortest <= 50\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> shortest <= average <= longest\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> shortest == 43 and longest == 96\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.isclose(average, 70.8970588235)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
