OK_FORMAT = True

test = {   'name': 'q4_2',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> isinstance(smallest_change_major, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> smallest_change_major == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
