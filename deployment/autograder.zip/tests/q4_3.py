OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': [0, 0, 0, 1, 2, 2],
    'suites': [   {   'cases': [   {'code': '>>> isinstance(gws_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(linguistics_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(rhetoric_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> gws_relative_change >= 64 and gws_relative_change <= 66\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> linguistics_relative_change >= 36 and linguistics_relative_change <= 38\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> rhetoric_relative_change >= 50 and rhetoric_relative_change <= 52\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
